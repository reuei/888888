import type { Site, Merchant, Product, Order, Package, WhitelistRecord, FinanceRecord, UserProfile, Category, Node, Sku, Complaint, InviteCode, Article, AdSlot, Coupon, CouponRecord, TemplateItem, User, UserGroup, UserLevel, LuckyNumber, RealnameRecord, Agent, AgentProduct, CommissionRecord, Gateway, MyPackage, BOrder, Invoice, Notification, OperationLog, RolePermission, ApiDoc, BackupRecord, DailyStat, MerchantStat, UserGrowthStat, SettlementRecord, Station, CardSecret, ImportBatch, FeeGroup, BannedProduct, StockAlert, Announcement } from '../types';

export const sProfile: UserProfile = {
  name: '总站长',
  avatar: 'S',
  balance: 0,
};

export const bProfile: UserProfile = {
  name: '商户_阿明',
  avatar: 'B',
  balance: 12850.65,
  shopName: '极速发卡',
};

export const sStats = [
  { title: '总交易额', value: '2,847,391.50', unit: '元', color: 'primary' as const },
  { title: '总订单量', value: '38,492', unit: '笔', color: 'success' as const },
  { title: '平台抽成收入', value: '186,472.80', unit: '元', color: 'warning' as const },
  { title: '商户数量', value: '1,286', sub: '待审核 32', color: 'danger' as const },
  { title: '用户数量', value: '56,832', unit: '人', color: 'primary' as const },
];

export const bStats = [
  { title: '今日订单', value: '284', unit: '笔', sub: '昨日 256 / 7天 1,842', color: 'primary' as const },
  { title: '今日交易额', value: '12,847.50', unit: '元', sub: '昨日 10,234 / 7天 89K', color: 'success' as const },
  { title: '待结算', value: '8,450.00', unit: '元', sub: 'T+1 结算周期', color: 'warning' as const },
  { title: '库存预警', value: '3', unit: '个商品', sub: '需补充卡密', color: 'danger' as const },
];

export const trendLabels = ['06-22', '06-23', '06-24', '06-25', '06-26', '06-27', '06-28'];
export const trendValues = [120, 132, 101, 134, 90, 230, 210];
export const bTrendValues1 = [120, 132, 101, 134, 230, 210, 284];
export const bTrendValues2 = [320, 432, 401, 434, 590, 630, 620];
export const bTrendValues3 = [82, 92, 71, 84, 130, 110, 142];

export const merchantRank = [
  { name: '极速发卡', amount: 482900 },
  { name: '蓝海数码', amount: 391200 },
  { name: '优惠券之家', amount: 284500 },
  { name: '云卡商城', amount: 198300 },
  { name: '卡密工坊', amount: 165000 },
  { name: '快发网络', amount: 142800 },
  { name: '便民发卡', amount: 128000 },
  { name: '数码驿站', amount: 105600 },
  { name: '充值中心', amount: 93200 },
  { name: '优选卡店', amount: 78000 },
];

export const sites: Site[] = [
  { id: '1', name: '官网加速', domain: 'www.example.com', template: 'PC-01', products: 4, nodes: 12, status: 'running', createdAt: '2026-01-15' },
  { id: '2', name: '商城防护', domain: 'shop.example.com', template: 'PC-02', products: 6, nodes: 8, status: 'running', createdAt: '2026-02-20' },
  { id: '3', name: '博客加速', domain: 'blog.demo.com', template: 'M-01', products: 2, nodes: 4, status: 'pending', createdAt: '2026-03-10' },
  { id: '4', name: '游戏盾', domain: 'game.xxx.com', template: 'PC-03', products: 3, nodes: 16, status: 'stopped', createdAt: '2026-04-05' },
  { id: '5', name: 'API网关', domain: 'api.xxx.com', template: 'M-02', products: 1, nodes: 6, status: 'running', createdAt: '2026-05-18' },
];

export const merchants: Merchant[] = [
  { id: 'M001', avatar: '速', shopName: '极速云', phone: '138****1234', registerAt: '2026-01-10', deposit: 5000, status: 'normal' },
  { id: 'M002', avatar: '蓝', shopName: '蓝海防护', phone: '139****5678', registerAt: '2026-02-15', deposit: 3000, status: 'normal' },
  { id: 'M003', avatar: '店', shopName: '站点卫士', phone: '137****9012', registerAt: '2026-03-20', deposit: 0, status: 'pending' },
  { id: 'M004', avatar: '云', shopName: '云盾科技', phone: '136****3456', registerAt: '2026-04-12', deposit: 2000, status: 'banned' },
];

export const products: Product[] = [
  { id: 'P001', name: 'VPN月卡', type: '虚拟商品', nodePool: '自动发卡', priceRange: '¥9.90 - ¥99.00', status: 'on' },
  { id: 'P002', name: '游戏点券100元', type: '充值卡', nodePool: '自动发卡', priceRange: '¥95.00 - ¥100.00', status: 'on' },
  { id: 'P003', name: 'Steam充值卡', type: '礼品卡', nodePool: '自动发卡', priceRange: '¥299.00 - ¥2999.00', status: 'off' },
  { id: 'P004', name: '话费充值50元', type: '充值卡', nodePool: '自动发卡', priceRange: '¥49.00 - ¥50.00', status: 'on' },
];

export const orders: Order[] = [
  { id: 'O202607100001', buyer: 'user_9527', merchant: '极速发卡', product: 'VPN月卡', amount: 29.00, status: 'paid', createdAt: '2026-07-10 10:23' },
  { id: 'O202607100002', buyer: 'user_3344', merchant: '蓝海数码', product: '游戏点券100元', amount: 95.00, status: 'pending', createdAt: '2026-07-10 09:45' },
  { id: 'O202607100003', buyer: 'user_7788', merchant: '优惠券之家', product: 'Steam充值卡', amount: 299.00, status: 'refunded', createdAt: '2026-07-09 22:10' },
  { id: 'O202607100004', buyer: 'user_1122', merchant: '云卡商城', product: '话费充值50元', amount: 49.00, status: 'closed', createdAt: '2026-07-09 18:33' },
];

export const packages: Package[] = [
  { id: 'PKG01', name: '入门版', flow: '100GB', bandwidth: '10Mbps', domains: 1, price: 9.90, period: '月' },
  { id: 'PKG02', name: '标准版', flow: '500GB', bandwidth: '50Mbps', domains: 3, price: 49.00, period: '月' },
  { id: 'PKG03', name: '专业版', flow: '2TB', bandwidth: '200Mbps', domains: 10, price: 199.00, period: '月' },
  { id: 'PKG04', name: '企业版', flow: '10TB', bandwidth: '1Gbps', domains: 50, price: 999.00, period: '月' },
];

export const whitelistRecords: WhitelistRecord[] = [
  { id: 'W001', domain: 'www.shop-a.com', purpose: '电商站点加速', icp: '京ICP备123456号', status: 'approved', createdAt: '2026-06-25' },
  { id: 'W002', domain: 'blog.demo-b.com', purpose: '个人博客', icp: '-', status: 'pending', createdAt: '2026-06-27' },
  { id: 'W003', domain: 'api.game-c.com', purpose: '游戏API', icp: '沪ICP备654321号', status: 'rejected', createdAt: '2026-06-26', reason: '资料不完整' },
];

export const financeRecords: FinanceRecord[] = [
  { id: 'F001', type: 'income', amount: 1299.00, balance: 12850.65, desc: '订单 O202606280001 分润', createdAt: '2026-06-28 10:25' },
  { id: 'F002', type: 'withdraw', amount: -5000.00, balance: 11551.65, desc: '提现至支付宝', createdAt: '2026-06-27 16:00' },
  { id: 'F003', type: 'expense', amount: -299.00, balance: 16551.65, desc: '套餐续费', createdAt: '2026-06-26 09:12' },
  { id: 'F004', type: 'frozen', amount: -200.00, balance: 16850.65, desc: '异常订单冻结', createdAt: '2026-06-25 14:33' },
];

export const categories: Category[] = [
  { id: 'C1', name: 'CDN 加速', parentId: null, sort: 1 },
  { id: 'C2', name: '高防 CDN', parentId: null, sort: 2 },
  { id: 'C3', name: '游戏盾', parentId: null, sort: 3 },
  { id: 'C4', name: '全球加速', parentId: null, sort: 4 },
  { id: 'C5', name: '企业级', parentId: 'C1', sort: 1 },
];

export const nodes: Node[] = [
  { id: 'N001', name: '北京电信-01', ip: '1.1.1.1', region: '华北', isp: '电信', type: '自建', health: 'healthy', enabled: true, latency: 12, uptime: '99.99%' },
  { id: 'N002', name: '上海联通-01', ip: '2.2.2.2', region: '华东', isp: '联通', type: '自建', health: 'healthy', enabled: true, latency: 15, uptime: '99.95%' },
  { id: 'N003', name: '广州移动-01', ip: '3.3.3.3', region: '华南', isp: '移动', type: '公开节点', health: 'warning', enabled: true, latency: 45, uptime: '98.50%' },
  { id: 'N004', name: 'Cloudflare-HK', ip: 'cf-hk.example.com', region: '海外', isp: 'BGP', type: 'Cloudflare', health: 'healthy', enabled: true, latency: 28, uptime: '99.90%' },
  { id: 'N005', name: '成都电信-01', ip: '4.4.4.4', region: '西南', isp: '电信', type: '自建', health: 'offline', enabled: false, latency: 0, uptime: '0.00%' },
];

export const skus: Sku[] = [
  { id: 'S001', name: '入门版', bandwidth: '10Mbps', flow: '100GB/月', domains: 1, ccLevel: '基础', price: 9.90 },
  { id: 'S002', name: '标准版', bandwidth: '50Mbps', flow: '500GB/月', domains: 3, ccLevel: '标准', price: 49.00 },
  { id: 'S003', name: '专业版', bandwidth: '200Mbps', flow: '2TB/月', domains: 10, ccLevel: '高级', price: 199.00 },
  { id: 'S004', name: '企业版', bandwidth: '1Gbps', flow: '10TB/月', domains: 50, ccLevel: '企业', price: 999.00 },
];

export const complaints: Complaint[] = [
  { id: 'CP001', orderId: 'O202606280003', plaintiff: 'user_7788', defendant: '站点卫士', reason: '未到账', status: 'pending', createdAt: '2026-06-28 09:00' },
  { id: 'CP002', orderId: 'O202606270056', plaintiff: 'user_3344', defendant: '蓝海防护', reason: '商品与描述不符', status: 'resolved', createdAt: '2026-06-27 14:20' },
  { id: 'CP003', orderId: 'O202606260012', plaintiff: 'user_9527', defendant: '极速云', reason: '无法访问', status: 'rejected', createdAt: '2026-06-26 11:30' },
];

export const inviteCodes: InviteCode[] = [
  { id: 'I001', code: 'INVITE2026A', maxUses: 100, usedCount: 32, expiry: '2026-12-31', status: 'active' },
  { id: 'I002', code: 'VIP888', maxUses: 50, usedCount: 50, expiry: '2026-06-01', status: 'expired' },
  { id: 'I003', code: 'TEST001', maxUses: 10, usedCount: 2, expiry: '2026-12-31', status: 'disabled' },
];

export const articles: Article[] = [
  { id: 'A001', title: '平台六一八活动公告', category: '平台公告', isTop: true, status: 'published', publishAt: '2026-06-18 10:00' },
  { id: 'A002', title: '关于调整结算周期的通知', category: '结算公告', isTop: false, status: 'published', publishAt: '2026-06-20 16:00' },
  { id: 'A003', title: '新手入驻指南', category: '帮助文档', isTop: false, status: 'draft', publishAt: '-' },
];

export const adSlots: AdSlot[] = [
  { id: 'AD001', name: 'PC 首页轮播', position: '电脑端首页顶部', size: '1920x400', status: 'on' },
  { id: 'AD002', name: '购卡页横幅', position: '购卡页中部', size: '1200x200', status: 'on' },
  { id: 'AD003', name: 'APP 启动页', position: 'APP 启动页', size: '750x1334', status: 'off' },
];

export const coupons: Coupon[] = [
  { id: 'CO001', batch: 'BATCH0618', type: 'fixed', value: 10, threshold: 50, total: 1000, received: 856, status: 'active' },
  { id: 'CO002', batch: 'BATCHNEW', type: 'percent', value: 20, threshold: 100, total: 500, received: 500, status: 'expired' },
];

export const couponRecords: CouponRecord[] = [
  { id: 'CR001', code: 'BATCH0618-001', batch: 'BATCH0618', user: 'user_9527', order: 'O202606280001', usedAt: '2026-06-28 10:25' },
  { id: 'CR002', code: 'BATCH0618-002', batch: 'BATCH0618', user: 'user_3344', order: 'O202606280002', usedAt: '2026-06-28 09:46' },
];

export const pcTemplates: TemplateItem[] = [
  { id: 'PC-01', name: '企业官网风格', type: 'pc' },
  { id: 'PC-02', name: '科技深蓝风格', type: 'pc' },
  { id: 'PC-03', name: '极简白风格', type: 'pc' },
];

export const mobileTemplates: TemplateItem[] = [
  { id: 'M-01', name: '移动端标准版', type: 'mobile' },
  { id: 'M-02', name: '移动端深色版', type: 'mobile' },
  { id: 'M-03', name: '移动端渐变版', type: 'mobile' },
  { id: 'M-04', name: '移动端卡片版', type: 'mobile' },
];

export const cardTemplates: TemplateItem[] = [
  { id: 'CARD-01', name: '经典购卡页', type: 'card' },
  { id: 'CARD-02', name: '暗色游戏风', type: 'card' },
  { id: 'CARD-03', name: '清新电商风', type: 'card' },
  { id: 'CARD-04', name: '极简科技风', type: 'card' },
  { id: 'CARD-05', name: '促销节日风', type: 'card' },
  { id: 'CARD-06', name: '会员专享风', type: 'card' },
  { id: 'CARD-07', name: '直播带货风', type: 'card' },
  { id: 'CARD-08', name: '企业采购风', type: 'card' },
  { id: 'CARD-09', name: '教育课程风', type: 'card' },
  { id: 'CARD-10', name: '云服务风', type: 'card' },
  { id: 'CARD-11', name: 'DIY 自定义', type: 'card' },
];

export const settlementRecords: SettlementRecord[] = [
  { id: 'SET001', merchant: '极速云', cycle: 'T+1', amount: 4820.00, fee: 48.20, netAmount: 4771.80, status: 'settled', time: '2026-06-28 10:00' },
  { id: 'SET002', merchant: '蓝海防护', cycle: 'T+1', amount: 3150.50, fee: 31.51, netAmount: 3118.99, status: 'settled', time: '2026-06-27 10:00' },
  { id: 'SET003', merchant: '站点卫士', cycle: 'T+7', amount: 1200.00, fee: 12.00, netAmount: 1188.00, status: 'pending', time: '2026-06-28 09:00' },
];

export const users: User[] = [
  { id: 'U001', nickname: 'user_9527', phone: '138****1234', level: 'VIP1', group: '默认分组', registerAt: '2026-01-10', status: 'normal' },
  { id: 'U002', nickname: 'user_3344', phone: '139****5678', level: '普通会员', group: '默认分组', registerAt: '2026-02-15', status: 'normal' },
  { id: 'U003', nickname: 'user_7788', phone: '137****9012', level: 'VIP2', group: '高价值用户', registerAt: '2026-03-20', status: 'banned' },
  { id: 'U004', nickname: 'user_1122', phone: '136****3456', level: '普通会员', group: '默认分组', registerAt: '2026-04-12', status: 'normal' },
];

export const userGroups: UserGroup[] = [
  { id: 'G1', name: '默认分组', userCount: 4820 },
  { id: 'G2', name: '高价值用户', userCount: 356 },
  { id: 'G3', name: '渠道引流用户', userCount: 128 },
];

export const userLevels: UserLevel[] = [
  { id: 'L1', name: '普通会员', minAmount: 0, discount: 1.0 },
  { id: 'L2', name: 'VIP1', minAmount: 500, discount: 0.95 },
  { id: 'L3', name: 'VIP2', minAmount: 2000, discount: 0.88 },
  { id: 'L4', name: 'VIP3', minAmount: 5000, discount: 0.8 },
];

export const luckyNumbers: LuckyNumber[] = [
  { id: 'N001', number: '888888', price: 88.00, sold: false },
  { id: 'N002', number: '666666', price: 66.00, sold: true },
  { id: 'N003', number: '168888', price: 48.00, sold: false },
  { id: 'N004', number: '5201314', price: 128.00, sold: false },
  { id: 'N005', number: '999999', price: 99.00, sold: false },
];

export const realnameRecords: RealnameRecord[] = [
  { id: 'R001', userId: 'U001', name: '张三', idCard: '11010119900101****', phone: '138****1234', status: 'approved', submittedAt: '2026-06-20 10:00' },
  { id: 'R002', userId: 'U002', name: '李四', idCard: '31010119900202****', phone: '139****5678', status: 'pending', submittedAt: '2026-06-27 14:30' },
  { id: 'R003', userId: 'U003', name: '王五', idCard: '44010119900303****', phone: '137****9012', status: 'rejected', submittedAt: '2026-06-25 09:15' },
];

export const agents: Agent[] = [
  { id: 'A001', name: '总代理-老李', parent: null, level: 1, commission: 15 },
  { id: 'A002', name: '一级代理-小张', parent: 'A001', level: 2, commission: 10 },
  { id: 'A003', name: '二级代理-阿强', parent: 'A002', level: 3, commission: 8 },
  { id: 'A004', name: '一级代理-小美', parent: 'A001', level: 2, commission: 10 },
];

export const agentProducts: AgentProduct[] = [
  { id: 'AP001', name: '基础CDN加速-代理版', source: '极速云', costPrice: 8.00, retailPrice: 12.00, status: 'on' },
  { id: 'AP002', name: '企业高防CDN-代理版', source: '蓝海防护', costPrice: 250.00, retailPrice: 299.00, status: 'on' },
  { id: 'AP003', name: '全球加速Pro-代理版', source: '站点卫士', costPrice: 180.00, retailPrice: 199.00, status: 'pending' },
];

export const commissionRecords: CommissionRecord[] = [
  { id: 'C001', agent: '一级代理-小张', orderId: 'O202606280001', amount: 29.90, status: 'settled', createdAt: '2026-06-28 10:30' },
  { id: 'C002', agent: '二级代理-阿强', orderId: 'O202606280002', amount: 5.90, status: 'pending', createdAt: '2026-06-28 09:50' },
  { id: 'C003', agent: '一级代理-小美', orderId: 'O202606270056', amount: 19.90, status: 'settled', createdAt: '2026-06-27 15:00' },
];

export const gateways: Gateway[] = [
  { id: 'GW001', name: '支付宝官方', channel: 'alipay', fee: 0.6, enabled: true, isDefault: true },
  { id: 'GW002', name: '微信支付商户号', channel: 'wxpay', fee: 0.6, enabled: true, isDefault: false },
  { id: 'GW003', name: '易支付-通道A', channel: 'epay', fee: 2.0, enabled: true, isDefault: false },
  { id: 'GW004', name: 'USDT-TRC20', channel: 'usdt', fee: 1.0, enabled: false, isDefault: false },
];

export const myPackages: MyPackage[] = [
  { id: 'MP001', name: '标准版', flow: '500GB', bandwidth: '50Mbps', domains: 3, expireAt: '2026-12-31', status: 'active' },
  { id: 'MP002', name: '专业版', flow: '2TB', bandwidth: '200Mbps', domains: 10, expireAt: '2027-01-15', status: 'active' },
  { id: 'MP003', name: '入门版', flow: '100GB', bandwidth: '10Mbps', domains: 1, expireAt: '2026-05-31', status: 'expired' },
];

export const bOrders: BOrder[] = [
  { id: 'O202606280001', product: '企业高防CDN', amount: 299.00, status: 'paid', createdAt: '2026-06-28 10:23', paidAt: '2026-06-28 10:25', packageId: 'PKG03', period: '1个月' },
  { id: 'O202606270088', product: '全球加速Pro', amount: 199.00, status: 'paid', createdAt: '2026-06-27 15:40', paidAt: '2026-06-27 15:42', packageId: 'PKG02', period: '1个月' },
  { id: 'O202606260056', product: '标准版套餐', amount: 49.00, status: 'refunded', createdAt: '2026-06-26 09:15', paidAt: '2026-06-26 09:16', packageId: 'PKG01', period: '1个月' },
  { id: 'O202606250042', product: '专业版套餐', amount: 199.00, status: 'paid', createdAt: '2026-06-25 14:30', paidAt: '2026-06-25 14:32', packageId: 'PKG02', period: '3个月' },
  { id: 'O202606240031', product: '入门版套餐', amount: 9.90, status: 'pending', createdAt: '2026-06-24 11:10', packageId: 'PKG01', period: '1个月' },
  { id: 'O202606230028', product: '企业版套餐', amount: 999.00, status: 'cancelled', createdAt: '2026-06-23 16:50', packageId: 'PKG04', period: '1个月' },
];

export const invoices: Invoice[] = [
  {
    id: 'INV20260628001',
    orderId: 'O202606280001',
    amount: 299.00,
    status: 'issued',
    type: 'company',
    title: '云盾科技有限公司',
    taxId: '91310101MA1G812345',
    items: [{ name: '企业高防CDN（1个月）', quantity: 1, unitPrice: 299.00, amount: 299.00 }],
    createdAt: '2026-06-28 10:30',
    issuedAt: '2026-06-28 10:35',
  },
  {
    id: 'INV20260627001',
    orderId: 'O202606270088',
    amount: 199.00,
    status: 'pending',
    type: 'personal',
    title: '张三',
    items: [{ name: '全球加速Pro（1个月）', quantity: 1, unitPrice: 199.00, amount: 199.00 }],
    createdAt: '2026-06-27 16:00',
  },
];

export const notifications: Notification[] = [
  { id: 'NT001', title: '新商户入驻待审核', content: '商户「云盾科技」提交入驻申请，请及时处理。', type: 'system', read: false, createdAt: '2026-06-28 11:20', link: '/s/merchant-audit' },
  { id: 'NT002', title: '域名过白申请被驳回', content: '您提交的 api.game-c.com 过白申请已被驳回，原因：资料不完整。', type: 'alert', read: false, createdAt: '2026-06-28 10:05', link: '/b/whitelist' },
  { id: 'NT003', title: '收到新订单 O202606280001', content: '用户 user_9527 购买了企业高防CDN，金额 ¥299.00。', type: 'order', read: true, createdAt: '2026-06-28 10:23', link: '/s/orders' },
  { id: 'NT004', title: '结算单 SET001 已打款', content: '您的 T+1 结算单 ¥4820.00 已通过支付宝打款。', type: 'finance', read: true, createdAt: '2026-06-28 09:30', link: '/b/finance' },
  { id: 'NT005', title: '节点池高防B 延迟告警', content: '节点池高防B 平均延迟超过 200ms，请关注。', type: 'alert', read: true, createdAt: '2026-06-27 22:15', link: '/s/nodes' },
];

export const operationLogs: OperationLog[] = [
  { id: 'L001', operator: 'admin', module: '商户管理', action: '审核通过', detail: '通过商户「云盾科技」入驻申请', ip: '192.168.1.10', createdAt: '2026-06-28 11:20:05' },
  { id: 'L002', operator: 'admin', module: '商品管理', action: '下架商品', detail: '下架商品「游戏盾专业版」', ip: '192.168.1.10', createdAt: '2026-06-28 10:15:33' },
  { id: 'L003', operator: 'admin', module: '财务管理', action: '手动结算', detail: '为「极速云」发起手动结算 ¥4820.00', ip: '192.168.1.12', createdAt: '2026-06-28 09:50:18' },
  { id: 'L004', operator: 'admin', module: '系统设置', action: '修改费率', detail: '修改默认分组费率为 2.0%', ip: '192.168.1.10', createdAt: '2026-06-27 16:40:22' },
];

export const roles: RolePermission[] = [
  { id: 'R001', name: '超级管理员', description: '拥有全部权限', permissions: ['*'], userCount: 1 },
  { id: 'R002', name: '运营专员', description: '负责商户、订单、用户日常运营', permissions: ['merchants', 'orders', 'users', 'complaints'], userCount: 3 },
  { id: 'R003', name: '财务人员', description: '负责结算、对账、网关配置', permissions: ['finance', 'settlement', 'payments'], userCount: 2 },
  { id: 'R004', name: '客服', description: '处理投诉、过白、实名审核', permissions: ['complaints', 'whitelist', 'user-realname'], userCount: 4 },
];

export const permissionOptions = [
  { key: 'dashboard', label: '仪表盘' },
  { key: 'sites', label: '站点管理' },
  { key: 'merchants', label: '商户管理' },
  { key: 'products', label: '商品管理' },
  { key: 'orders', label: '订单管理' },
  { key: 'users', label: '会员/用户管理' },
  { key: 'agents', label: '代理/分销管理' },
  { key: 'finance', label: '财务管理' },
  { key: 'payments', label: '支付网关管理' },
  { key: 'templates', label: '模板与前端管理' },
  { key: 'articles', label: '文章/公告管理' },
  { key: 'ads', label: '广告位管理' },
  { key: 'coupons', label: '优惠券/营销管理' },
  { key: 'system', label: '系统设置' },
  { key: 'operation-logs', label: '操作日志' },
  { key: 'roles', label: '权限角色管理' },
];

export const apiDocs: ApiDoc[] = [
  { id: 'A001', method: 'POST', path: '/api/v1/sites', name: '创建站点', desc: '创建新的 CDN 站点', group: '站点' },
  { id: 'A002', method: 'GET', path: '/api/v1/sites', name: '站点列表', desc: '获取当前商户的站点列表', group: '站点' },
  { id: 'A003', method: 'PUT', path: '/api/v1/sites/:id', name: '更新站点', desc: '更新站点配置', group: '站点' },
  { id: 'A004', method: 'DELETE', path: '/api/v1/sites/:id', name: '删除站点', desc: '删除指定站点', group: '站点' },
  { id: 'A005', method: 'POST', path: '/api/v1/orders', name: '创建订单', desc: '创建套餐购买订单', group: '订单' },
  { id: 'A006', method: 'GET', path: '/api/v1/orders', name: '订单列表', desc: '获取订单列表', group: '订单' },
  { id: 'A007', method: 'POST', path: '/api/v1/whitelist', name: '过白申请', desc: '提交域名过白申请', group: '过白' },
  { id: 'A008', method: 'GET', path: '/api/v1/finance/records', name: '资金流水', desc: '获取资金流水记录', group: '财务' },
];

export const backupRecords: BackupRecord[] = [
  { id: 'B001', name: '全量备份-20260628-020000', size: '1.2GB', type: 'auto', status: 'success', createdAt: '2026-06-28 02:00:00' },
  { id: 'B002', name: '数据库备份-20260627-020000', size: '860MB', type: 'auto', status: 'success', createdAt: '2026-06-27 02:00:00' },
  { id: 'B003', name: '手动备份-20260626', size: '1.1GB', type: 'manual', status: 'success', createdAt: '2026-06-26 15:30:00' },
  { id: 'B004', name: '全量备份-20260625-020000', size: '1.0GB', type: 'auto', status: 'failed', createdAt: '2026-06-25 02:00:00' },
];

export const dailyStats: DailyStat[] = [
  { date: '06-22', revenue: 18200, orders: 420, users: 320, merchants: 12 },
  { date: '06-23', revenue: 21500, orders: 510, users: 380, merchants: 15 },
  { date: '06-24', revenue: 19800, orders: 460, users: 290, merchants: 10 },
  { date: '06-25', revenue: 24300, orders: 580, users: 450, merchants: 18 },
  { date: '06-26', revenue: 22100, orders: 520, users: 410, merchants: 14 },
  { date: '06-27', revenue: 28900, orders: 680, users: 520, merchants: 22 },
  { date: '06-28', revenue: 26400, orders: 610, users: 480, merchants: 19 },
];

export const merchantStats: MerchantStat[] = [
  { merchant: '极速云', revenue: 482900, orders: 1250, avgOrderValue: 386.32, growth: 12.5 },
  { merchant: '蓝海防护', revenue: 391200, orders: 980, avgOrderValue: 399.18, growth: 8.3 },
  { merchant: '站点卫士', revenue: 284500, orders: 720, avgOrderValue: 395.14, growth: -2.1 },
  { merchant: '云盾科技', revenue: 198300, orders: 510, avgOrderValue: 388.82, growth: 5.7 },
  { merchant: '安全链', revenue: 165000, orders: 420, avgOrderValue: 392.86, growth: 15.2 },
];

export const userGrowthStats: UserGrowthStat[] = [
  { date: '06-22', newUsers: 120, activeUsers: 4520, paidUsers: 380 },
  { date: '06-23', newUsers: 132, activeUsers: 4610, paidUsers: 395 },
  { date: '06-24', newUsers: 101, activeUsers: 4580, paidUsers: 402 },
  { date: '06-25', newUsers: 134, activeUsers: 4720, paidUsers: 418 },
  { date: '06-26', newUsers: 90, activeUsers: 4690, paidUsers: 410 },
  { date: '06-27', newUsers: 230, activeUsers: 4920, paidUsers: 450 },
  { date: '06-28', newUsers: 210, activeUsers: 5100, paidUsers: 465 },
];

export const stations: Station[] = [
  { id: 'ST01', name: '华东分站', domain: 'east.card.com', themeColor: '#2F6BFF', superAdmin: '张三', settleMode: 't1', merchantCount: 156, orderCount: 8542, revenue: 482900, status: 'active', createdAt: '2026-01-15' },
  { id: 'ST02', name: '华南分站', domain: 'south.card.com', themeColor: '#06B6D4', superAdmin: '李四', settleMode: 't0', merchantCount: 89, orderCount: 4231, revenue: 284500, status: 'active', createdAt: '2026-02-20' },
  { id: 'ST03', name: '华北分站', domain: 'north.card.com', themeColor: '#F97316', superAdmin: '王五', settleMode: 't7', merchantCount: 42, orderCount: 1856, revenue: 98300, status: 'suspended', createdAt: '2026-03-10' },
];

export const cardSecrets: CardSecret[] = [
  { id: 'CS001', productId: 'P001', merchantId: 'M001', content: 'XXXX-XXXX-XXXX-001', status: 'unsold', importBatchId: 'B001', createdAt: '2026-07-01' },
  { id: 'CS002', productId: 'P001', merchantId: 'M001', content: 'XXXX-XXXX-XXXX-002', status: 'sold', orderId: 'O202607100001', importBatchId: 'B001', createdAt: '2026-07-01' },
  { id: 'CS003', productId: 'P002', merchantId: 'M002', content: 'YYYY-YYYY-YYYY-001', status: 'locked', importBatchId: 'B002', createdAt: '2026-07-02' },
];

export const importBatches: ImportBatch[] = [
  { id: 'B001', operatorId: 'M001', operatorRole: 'b', total: 500, success: 498, fail: 2, deliverMode: 'sequential', createdAt: '2026-07-01' },
  { id: 'B002', operatorId: 'M002', operatorRole: 'b', total: 200, success: 200, fail: 0, deliverMode: 'random', createdAt: '2026-07-02' },
];

export const feeGroups: FeeGroup[] = [
  { id: 'FG01', name: '标准费率', rate: 0.02, merchantCount: 856, description: '默认2%费率' },
  { id: 'FG02', name: 'VIP费率', rate: 0.01, merchantCount: 234, description: 'VIP商户1%费率' },
  { id: 'FG03', name: '大客户费率', rate: 0.005, merchantCount: 56, description: '大客户0.5%费率' },
];

export const bannedProducts: BannedProduct[] = [
  { id: 'BP01', keyword: '违禁品A', category: '虚拟商品', matchType: 'keyword', createdAt: '2026-06-01' },
  { id: 'BP02', keyword: '违法服务', category: '服务类', matchType: 'keyword', createdAt: '2026-06-02' },
];

export const stockAlerts: StockAlert[] = [
  { id: 'SA01', productId: 'P001', productName: 'VPN月卡', threshold: 10, currentStock: 3, merchantName: '极速发卡', status: 'alerting' },
  { id: 'SA02', productId: 'P003', productName: 'Steam充值卡', threshold: 20, currentStock: 5, merchantName: '蓝海数码', status: 'alerting' },
];

export const announcements: Announcement[] = [
  { id: 'A01', title: '系统升级公告', content: '系统将于今晚22:00-23:00进行升级维护，届时无法下单。', type: 'popup', isPopup: true, countdown: 5, publishAt: '2026-07-09', status: 'published' },
  { id: 'A02', title: '费率调整通知', content: '即日起标准费率调整为2%，VIP费率1%。', type: 'notice', isPopup: false, countdown: 0, publishAt: '2026-07-08', status: 'published' },
];

